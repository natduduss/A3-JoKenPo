import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 * Classe client
 * Cliente para o jogo que pode se conectar a um servidor para jogar contra a
 * CPU ou outro cliente.
 */
public class client {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            // Solicita ao usuário o endereço do servidor
            System.out.println(
                    "Digite 'localhost' para se conectar ao servidor local ou insira o endereço IP do servidor:");
            String serverAddress = scanner.nextLine().trim();

            // Verifica se o endereço é localhost e converte para 127.0.0.1
            if (serverAddress.equalsIgnoreCase("localhost")) {
                serverAddress = "127.0.0.1";
            }

            // Estabelece conexão com o servidor na porta 12345
            Socket socket = new Socket(serverAddress, 12345);
            DataInputStream input = new DataInputStream(socket.getInputStream());
            DataOutputStream output = new DataOutputStream(socket.getOutputStream());

            // Solicita ao usuário o modo de jogo
            System.out.println("\nDigite 'u' para jogar contra a CPU ou 't' para jogar contra outro CLIENT:\n");
            String gameMode = scanner.nextLine();
            output.writeUTF(gameMode); // Envia o modo de jogo ao servidor
            output.flush(); // Certifique-se de que os dados sejam enviados imediatamente

            // Seleciona o modo de jogo com base na entrada do usuário
            switch (gameMode) {
                case "u":
                    playAgainstCpu(scanner, output, input);
                    break;
                case "t":
                    playAgainstClient(scanner, output, input);
                    break;
                default:
                    System.out.println("Modo de jogo inválido. Por favor, reinicie o programa e escolha 'u' ou 't'.");
                    break;
            }

            // Fecha o socket ao terminar
            socket.close();
        } catch (UnknownHostException e) {
            System.err.println("Endereço do servidor desconhecido: " + e.getMessage());
            e.printStackTrace();
        } catch (ConnectException e) {
            System.err.println("Falha na conexão ao servidor: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Erro de comunicação: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Função para jogar contra a CPU
    private static void playAgainstCpu(Scanner scanner, DataOutputStream output, DataInputStream input)
            throws IOException {
        int playerScore = 0;
        int cpuScore = 0;
        int ties = 0;

        System.out.println("\nJogo contra a CPU iniciado...");
        System.out.println("\nDigite sua jogada (pedra, papel, tesoura) ou 'sair' para terminar:\n");

        while (true) {
            // Solicita ao usuário uma jogada válida
            String userMove = getValidMove(scanner);
            if (userMove.equals("sair")) {
                output.writeUTF("sair");
                output.flush();
                break;
            }
            output.writeUTF(userMove);
            output.flush();

            // Recebe a jogada da CPU e o resultado do servidor
            String cpuMove = input.readUTF();
            String result = input.readUTF();

            // Imprime a jogada da CPU e o resultado
            System.out.println("__________________________________________________________________");
            System.out.println("\nCPU jogou: " + cpuMove);
            System.out.println("Resultado: " + result);

            // Atualiza o placar com base no resultado
            if (result.equals("Empate!")) {
                ties++;
            } else if (result.equals("Você ganhou!")) {
                playerScore++;
            } else if (result.equals("Você perdeu!")) {
                cpuScore++;
            }

            // Mostra o placar atual
            System.out.println("Placar: Jogador: " + playerScore + " | Empates: " + ties + " | CPU: " + cpuScore);
            System.out.println("__________________________________________________________________");

            System.out.println("\nDigite sua jogada (pedra, papel, tesoura) ou 'sair' para terminar:\n");
        }

        // Mostra o placar final quando o jogo termina
        System.out.println("__________________________________________________________________");
        System.out.println("\nPLACAR FINAL: Jogador: " + playerScore + " | Empates: " + ties + " | CPU: " + cpuScore);
        System.out.println("__________________________________________________________________\n");
    }

    // Função para jogar contra outro cliente
    private static void playAgainstClient(Scanner scanner, DataOutputStream output, DataInputStream input)
            throws IOException {
        int player1Score = 0;
        int player2Score = 0;
        int ties = 0;

        System.out.println("\nO jogo contra outro cliente será iniciado... Faça a sua Jogada, e aguarde a Jogada de seu oponente.\n");
        System.out.println("Digite sua jogada (pedra, papel, tesoura) ou 'sair' para terminar: \n");

        while (true) {
            // Solicita ao usuário uma jogada válida
            String userMove = getValidMove(scanner);
            if (userMove.equals("sair")) {
                output.writeUTF("sair");
                output.flush();
                break;
            }
            output.writeUTF(userMove);
            output.flush();

            // Recebe a jogada do oponente e o resultado do servidor
            String opponentMove = input.readUTF();
            if (opponentMove.equals("sair")) {
                System.out.println("Oponente saiu do jogo.");
                break;
            }
            String resultForUser = input.readUTF(); // Receber o resultado para o usuário

            // Imprime a jogada do oponente e o resultado
            System.out.println("__________________________________________________________________\n");
            System.out.println("Oponente jogou: " + opponentMove);
            System.out.println("Resultado: " + resultForUser);

            // Atualiza o placar com base no resultado
            if (resultForUser.equals("Empate!")) {
                ties++;
            } else if (resultForUser.equals("Você ganhou!")) {
                player1Score++;
            } else if (resultForUser.equals("Você perdeu!")) {
                player2Score++;
            }

            // Mostra o placar atual
            System.out.println(
                    "Placar: Jogador1: " + player1Score + " | Empates: " + ties + " | Jogador2: " + player2Score);
            System.out.println("__________________________________________________________________\n");

            System.out.println("Digite sua jogada (pedra, papel, tesoura) ou 'sair' para terminar: \n");
        }

        // Mostra o placar final quando o jogo termina
        System.out.println("__________________________________________________________________\n");
        System.out.println(
                "Placar Final: Jogador1: " + player1Score + " | Empates: " + ties + " | Jogador2: " + player2Score);
        System.out.println("__________________________________________________________________\n");
    }

    // Função para validar a jogada do usuário
    private static String getValidMove(Scanner scanner) {
        String userMove;
        while (true) {
            userMove = scanner.nextLine().trim().toLowerCase();
            // Verifica se a jogada é válida
            if (userMove.equals("pedra") || userMove.equals("papel") || userMove.equals("tesoura")
                    || userMove.equals("sair")) {
                break;
            } else {
                // Pede ao usuário para digitar novamente se a entrada for inválida
                System.out.println("\nEntrada inválida. Por favor, digite 'pedra', 'papel' ou 'tesoura':\n");
            }
        }
        return userMove;
    }
}
