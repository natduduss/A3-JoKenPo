import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class server {
    private static final int PORT = 12345; // Porta na qual o servidor vai escutar as conexões
    private static final BlockingQueue<Player> twoPlayerQueue = new LinkedBlockingQueue<>(); // Fila para gerenciar os jogadores que desejam jogar entre si
    private static final ExecutorService pool = Executors.newFixedThreadPool(10); // ExecutorService para gerenciar múltiplas conexões de clientes

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) { // Cria o ServerSocket na porta especificada
            System.out.println("Servidor iniciado. Aguardando conexões...\n");
            String serverIP = InetAddress.getLocalHost().getHostAddress(); // Obtém o endereço IP do servidor
            System.out.println("Jogadores devem se conectar ao IP: " + serverIP + " na porta " + PORT + "\n");

            while (true) {
                Socket playerSocket = serverSocket.accept(); // Aguarda uma conexão de um cliente
                pool.execute(() -> handlePlayer(playerSocket)); // Lida com o cliente em uma nova thread
            }
        } catch (IOException e) {
            System.err.println("Erro no servidor: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void handlePlayer(Socket playerSocket) {
        try {
            DataInputStream input = new DataInputStream(playerSocket.getInputStream());
            DataOutputStream output = new DataOutputStream(playerSocket.getOutputStream());

            System.out.println("Jogador conectado: " + playerSocket.getInetAddress().getHostAddress());
            String gameMode = input.readUTF(); // Lê o modo de jogo do cliente
            System.out.println("\nModo de jogo recebido: " + gameMode);

            if ("u".equals(gameMode)) {
                handleCpuGame(input, output); // Inicia o jogo contra a CPU
            } else if ("t".equals(gameMode)) {
                Player player = new Player(playerSocket, input, output);
                twoPlayerQueue.put(player); // Adiciona o jogador na fila para jogar contra outro jogador
                System.out.println("\nJogador adicionado à fila de dois jogadores. Aguardando outro jogador...\n");

                synchronized (twoPlayerQueue) {
                    if (twoPlayerQueue.size() >= 2) { // Se houver pelo menos dois jogadores na fila
                        Player player1 = twoPlayerQueue.take();
                        Player player2 = twoPlayerQueue.take();
                        System.out.println("Encontrado oponente. Iniciando jogo...\n");
                        pool.execute(() -> handleClientGame(player1, player2)); // Inicia o jogo entre dois jogadores
                    }
                }
            } else {
                System.out.println("Modo de jogo inválido recebido: " + gameMode);
                output.writeUTF("Modo de jogo inválido");
                output.flush();
                playerSocket.close();
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Erro ao lidar com o jogador: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void handleCpuGame(DataInputStream input, DataOutputStream output) {
        int playerScore = 0;
        int cpuScore = 0;
        int ties = 0;

        try {
            while (true) {
                String userMove = input.readUTF(); // Lê a jogada do usuário
                if ("sair".equals(userMove)) {
                    System.out.println("__________________________________________________________________\n");
                    System.out.println("\nJogador decidiu sair do jogo.\n");
                    break;
                }
                String cpuMove = getCpuMove(); // Gera uma jogada aleatória para a CPU
                String result = determineWinner(userMove, cpuMove); // Determina o resultado da rodada

                if ("Empate!".equals(result)) {
                    ties++;
                } else if ("Você ganhou!".equals(result)) {
                    playerScore++;
                } else {
                    cpuScore++;
                }

                output.writeUTF(cpuMove); // Envia a jogada da CPU para o usuário
                output.writeUTF(result); // Envia o resultado da rodada para o usuário
                output.flush();
                System.out.println("__________________________________________________________________\n");
                System.out.println("Movimento do jogador: " + userMove + " \nMovimento da CPU: " + cpuMove + " \n\nResultado: " + result);
                System.out.println("__________________________________________________________________\n");
                System.out.println("\nPLACAR: Jogador: " + playerScore + " | Empates: " + ties + " | CPU: " + cpuScore + "\n");
            }
        } catch (IOException e) {
            System.err.println("Conexão encerrada inesperadamente durante o jogo contra a CPU: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("__________________________________________________________________\n");
        System.out.println("PLACAR FINAL: Jogador: " + playerScore + " | Empates: " + ties + " | CPU: " + cpuScore);
        System.out.println("__________________________________________________________________\n");

    }

    private static void handleClientGame(Player player1, Player player2) {
        int player1Score = 0;
        int player2Score = 0;
        int ties = 0;

        try {
            while (true) {
                String userMove1 = player1.input.readUTF(); // Lê a jogada do jogador 1
                if ("sair".equals(userMove1)) {
                    System.out.println("__________________________________________________________________\n");
                    System.out.println("\nJogador 1 decidiu sair do jogo.\n");
                    player2.output.writeUTF("sair");
                    player2.output.flush();
                    break;
                }

                String userMove2 = player2.input.readUTF(); // Lê a jogada do jogador 2
                if ("sair".equals(userMove2)) {
                    System.out.println("Jogador 2 decidiu sair do jogo.");
                    player1.output.writeUTF("sair");
                    player1.output.flush();
                    break;
                }

                player1.output.writeUTF(userMove2); // Envia a jogada do jogador 2 para o jogador 1
                player2.output.writeUTF(userMove1); // Envia a jogada do jogador 1 para o jogador 2

                String resultForUser1 = determineWinner(userMove1, userMove2); // Determina o resultado para o jogador 1
                String resultForUser2 = determineWinner(userMove2, userMove1); // Determina o resultado para o jogador 2

                if ("Empate!".equals(resultForUser1)) {
                    ties++;
                } else if ("Você ganhou!".equals(resultForUser1)) {
                    player1Score++;
                } else {
                    player2Score++;
                }

                player1.output.writeUTF(resultForUser1); // Envia o resultado para o jogador 1
                player2.output.writeUTF(resultForUser2); // Envia o resultado para o jogador 2
                player1.output.flush();
                player2.output.flush();
                System.out.println("__________________________________________________________________\n");
                System.out.println("Movimento do Jogador 1: " + userMove1 + "\nMovimento do Jogador 2: " + userMove2);
                System.out.println("\nResultado para jogador 1: " + resultForUser1 + "\nResultado para jogador 2: " + resultForUser2);
                System.out.println("__________________________________________________________________\n");
                System.out.println("PLACAR: Jogador1: " + player1Score + " | Empates: " + ties + " | Jogador2: " + player2Score);
            }
        } catch (IOException e) {
            System.err.println("Conexão encerrada inesperadamente durante o jogo entre Jogadores: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                player1.close();
                player2.close();
            } catch (IOException e) {
                System.err.println("Erro ao fechar conexões: " + e.getMessage());
            }
        }
        System.out.println("__________________________________________________________________\n");
        System.out.println("PLACAR FINAL: Jogador 1: " + player1Score + " | Empates: " + ties + " | Jogador 2: " + player2Score);
        System.out.println("__________________________________________________________________\n");

    }

    // Função para gerar a jogada da CPU de forma aleatória
    private static String getCpuMove() {
        String[] moves = {"pedra", "papel", "tesoura"};
        int index = (int) (Math.random() * moves.length);
        return moves[index];
    }

    // Função para determinar o vencedor da rodada
    private static String determineWinner(String move1, String move2) {
        if (move1.equals(move2)) {
            return "Empate!";
        } else if ((move1.equals("pedra") && move2.equals("tesoura")) ||
                   (move1.equals("papel") && move2.equals("pedra")) ||
                   (move1.equals("tesoura") && move2.equals("papel"))) {
            return "Você ganhou!";
        } else {
            return "Você perdeu!";
        }
    }

    // Classe Player para encapsular as informações do jogador
    private static class Player {
        Socket socket;
        DataInputStream input;
        DataOutputStream output;

        Player(Socket socket, DataInputStream input, DataOutputStream output) {
            this.socket = socket;
            this.input = input;
            this.output = output;
        }

        void close() throws IOException {
            input.close();
            output.close();
            socket.close();
        }
    }
}